/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.smartagro.inter;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import java.awt.GridLayout;

import com.smartagro.model.Usuario;
import com.smartagro.inter.LoginFrame;
import com.smartagro.inter.MainFrame;
/**
 *
 * @author Marti
 */
public class ParcelaFrame extends JFrame {
    public ParcelaFrame(Usuario usuario) {
        setTitle("Gestión de Parcelas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 350);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(6, 1, 10, 10)); 
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Bienvenido/a: " + usuario.getCorreo(), JLabel.CENTER));

        panel.add(new JButton("📋 Ver Parcelas"));
        panel.add(new JButton("➕ Agregar Parcelas"));
        panel.add(new JButton("✏️ Editar Parcelas"));
        panel.add(new JButton("❌ Eliminar Parcelas"));
        
        // Botón para volver al menú principal
        JButton botonVolver = new JButton("🔙 Volver al Menú Principal");
        botonVolver.addActionListener(e -> {
            dispose(); // cerrar esta ventana
            new MainFrame(usuario); // abrir el menú principal
        });
        panel.add(botonVolver);

        add(panel);
        setVisible(true);
    }
}
