/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.smartagro.inter;
import javax.swing.*;
import java.awt.*;
import com.smartagro.model.Usuario;
import com.smartagro.inter.LoginFrame;
/**
 *
 * @author Marti
 */

public class MainFrame extends JFrame {
    public MainFrame(Usuario usuario) {
        setTitle("SmartAgro - Menú Principal");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 350);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnAgricultores = new JButton("👨‍🌾 Gestionar Agricultores");
        JButton btnParcelas = new JButton("🌱 Gestionar Parcelas");
        JButton salirButton = new JButton("❌ Cerrar sesión");

        btnAgricultores.addActionListener(e -> {
            dispose(); // cerrar el menú
            new AgricultorFrame(usuario);
        });

        btnParcelas.addActionListener(e -> {
            dispose();
            new ParcelaFrame(usuario);
        });
        
        // Mostrar mensaje antes de cerrar
        salirButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Sesión cerrada con éxito");
            System.exit(0); // Cierra la app
        });

        panel.add(btnAgricultores);
        panel.add(btnParcelas);
        panel.add(salirButton);
        
        add(panel);
        setVisible(true);
    }
}
